package stockdataa;

/**
 * Interface stock that performs operations of a stock.
 */

public interface Stock {
  String printDataAt(String date);

  double getData(String date);

  int getShares();

  String getTicker();

  Stock1 addShares(int numShares);

  String sharesToJSON();
}
