package stockdataa;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import static java.lang.Math.min;
import static stockdataa.DataHelpers.padLeft;
import static stockdataa.DataHelpers.padRight;

/**
 * Class that holds all information about a stock.
 */

public class SmartStock implements Stock {


  // buyDate - The initial date the stock was bought
  //    This should be in the format: YYYY-MM-DD
  private Double shares;
  private String ticker;
  // I changed this to a date object from string so we cna compare dates
  // using the Collections.max() function
  // They key will be a LocalDate object in 'YYYY-MM-DD' format
  // and the values in the int[] will be
  // (0:open,1:high,2:low,3:close,4:volume) - length = 5
  private Map<LocalDate, Double> stockData;

  private Map<LocalDate, Pair<Double,Double>> BuyDates;




  /**
   * Constrcutor that gets each stock.
   *
   * @param ticker of the stock.
   * @param data   date and price of the stock.
   * @param myBuyDates A String consisting of dates when the stock was bought,
   *                   the shares bought at that date, and the commission fee paid.
   */

  public SmartStock(String ticker, String data,
                    String myBuyDates) throws IllegalArgumentException {
    double shares = 0;
    this.ticker = ticker;

    if (data.equals("API")) {
      this.stockData = DataHelpers.getStockData(ticker);
    } else {
      this.stockData = parseStock(data);
    }

    //TODO: PARSE BUY DATES
    // COMSHARES SHOULD BE IN FORMAT:
    // "(DATESTRING1, SHARES1, COMM1);(DATESTRING2, SHARES2, COMM2); ..."

    try{
      this.BuyDates = parseBuyDates(myBuyDates);
    } catch(IllegalArgumentException e) {
      throw e;
    }

    for(LocalDate key: this.BuyDates.keySet()) {
      shares += this.BuyDates.get(key).a;
    }

    this.shares = shares;

    // This function gets the value at the current date
  }

  private Map<LocalDate, Pair<Double,Double>> parseBuyDates( String myBuyDates)
          throws IllegalArgumentException {

    if (!myBuyDates.matches("[0-9-,.); (]+")) {
      throw new IllegalArgumentException("Unexpected character was found in stock data. "
              + "Please try again.");
    }

    Map<LocalDate, Pair<Double,Double>> stockDateData = new HashMap<LocalDate, Pair<Double,Double>>();
    String[] dateInfo = myBuyDates.split(";");

    for (int i = 0; i < dateInfo.length; i++) {

      String m2 = dateInfo[i].replaceAll("[() ]", "");

      String[] info2 = m2.split(",");

      // This will throw an error if the date was entered wrong so ok here
      LocalDate myKey;
      try{
        myKey = LocalDate.parse(info2[0]);
      } catch(Exception e) {
        throw new IllegalArgumentException("");
      }


      if(info2[1].length() == 0) {
        if(info2[2].length() != 0) {
          info2[1] = info2[2];
        } else {
          throw new IllegalArgumentException("Unexpected input in string data.");
        }
      }
      if (!stockDateData.containsKey(myKey)) {
        Pair<Double, Double> myPair;
        try{
          double numShares = Integer.parseInt(info2[1]);
          double commFee = Double.parseDouble(info2[2]);
          myPair = new Pair<Double, Double>(numShares, commFee);
        } catch(Exception e) {
          throw new IllegalArgumentException("Number of shares could not " +
                  "be parsed to an integer " +
                  "or commission fee could not be parsed." +
                  " Please check input and try again.");
        }

        stockDateData.put(myKey, myPair);
      }
      // This will throw an error if the # was entered wrong, so we should be good here.

    }

    return stockDateData;
  }


  /**
   * Constructor that gets each stock.
   *
   * @param ticker of the stock.
   * @param shares bought in the stock.
   * @param data   maps date and price of the stock.
   * @param buyDate string of the date the stock was bought in yyyy-MM-DD format.
   * @param commission the commission fee for the transaction
   */

  private SmartStock(String ticker, double shares, Map<LocalDate, Double> data,
                     String buyDate, double commission) {
    this.shares = shares;
    this.ticker = ticker;
    this.stockData = data;
    Pair<Double,Double> myPair = new Pair<Double,Double>(shares,commission);
    LocalDate myDate;
    try {
      myDate = LocalDate.parse(buyDate);
    } catch (Exception e) {
      throw new IllegalArgumentException("Buy-date could not be parsed. " +
              "Please check the input string and try again.");
    }
    HashMap<LocalDate, Pair<Double,Double>> myBuyDates;
    myBuyDates = new HashMap<LocalDate, Pair<Double,Double>>();
    myBuyDates.put(myDate,myPair);
    this.BuyDates = myBuyDates;
  }


  /**
   * Constrcutor that gets each stock.
   *
   * @param ticker of the stock.
   * @param data   date and price of the stock.
   * @param BuyDates A map with dates stock was bought as the key and a pair object
   *                 containing the price and number of stocks bought.
   */

  public SmartStock(String ticker, String data,
                    Map<LocalDate, Pair<Double,Double>> BuyDates) {
    this.shares = shares;
    this.ticker = ticker;

    if (data.equals("API")) {
      this.stockData = DataHelpers.getStockData(ticker);
    } else {
      this.stockData = parseStock(data);
    }

    this.BuyDates = BuyDates;


    // This function gets the value at the current date
  }

  private SmartStock(String ticker, double shares, Map<LocalDate, Double> data,
                     Map<LocalDate, Pair<Double,Double>> myBuyDates) {
    this.shares = shares;
    this.ticker = ticker;
    this.stockData = data;
    this.BuyDates = myBuyDates;
  }

  public Map<LocalDate, Pair<Double,Double>> getBuyDates() {

    return this.BuyDates;
  }

  /*
  IN PORTFOLIO:
  Pair<Character, Integer> myPair = DataHelpers.createTimeInterval(d1, d2);
    char timeType = myPair.a;
    int timeSplit = myPair.b;

    THIS FUNCTION SHOULD RETURN THE VALUE AT EACH KEY GROUPING OF THE STOCK
    THE PORTFOLIO WILL THEN SPLIT THE VALUES AS NECESSARY

    THEN FOR EACH STOCK DATE WE GET AN OVERALL MAP and do myMap.merge(key, VALUE, Integer::sum).
    This way for each date we put in a value. If key exists in myMap we add VALUE to it, otherwise
    we create the key and map it to VALUE.

    For the first stock we will just use the value outputted, then for each subsequent stock we
    will add the values to it.
    https://stackoverflow.com/questions/40158605/merge-two-maps-with-java-8
   */
  public Map<LocalDate, Double> timeIntervalValues(String date1, String date2, char timeType) throws IllegalArgumentException {
    LocalDate d1;
    LocalDate d2;
    try{
      d1 = LocalDate.parse(date1);
      d2 = LocalDate.parse(date2);
    } catch(Exception e) {
      throw new IllegalArgumentException("Your date strings could not be parsed. " +
              "Please check your inputs and try again");
    }


    LocalDate minDate = Collections.min(this.BuyDates.keySet());
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    Map<LocalDate, Double> newPrices;
    if(timeType == 'D') {
      newPrices =  this.getMyStockDate(date1, date2, dtf.format(minDate));
    } else {
      newPrices = DataHelpers.getStockData(this.ticker, date1,
              date2, timeType, dtf.format(minDate));
    }


    Comparator<LocalDate> comparator = LocalDate::compareTo;

    SortedSet<LocalDate> priceKeys = new TreeSet<>(comparator);
    priceKeys.addAll(newPrices.keySet());


    SortedSet<LocalDate> buyKeys = new TreeSet<>(comparator);
    buyKeys.addAll(this.BuyDates.keySet());

    Iterator<LocalDate> buyIt = buyKeys.iterator();
    LocalDate curBuyKey = buyIt.next();

    if(curBuyKey.isAfter(d2)){
      return new HashMap<LocalDate, Double>();
    }


    LocalDate nextBuy;
    if(buyIt.hasNext()) {
      nextBuy = buyIt.next();
    } else {
      nextBuy = null;
    }

    Pair<Double, Double> curBuy = BuyDates.get(curBuyKey);

    double curTotStock = curBuy.a;
    double curTotComiss = curBuy.b;


    // This is the earliest date we check against our buy keys
    // If the next buy Key is still before the current date, sum the
    // total number of stocks and commission for the current state and update
    // otherwise we keep the current state as the start state
    LocalDate firstDate = priceKeys.first();
    boolean finDate = false;

    while(!Objects.isNull(nextBuy) && !finDate) {
      if(!nextBuy.isAfter(firstDate)) {
        curBuyKey = nextBuy;
        if(buyIt.hasNext()) {
          nextBuy = buyIt.next();
        } else {
          nextBuy = null;
        }
        curBuy = BuyDates.get(curBuyKey);
        curTotStock += curBuy.a;
        curTotComiss += curBuy.b;
      } else {
        finDate = true;
      }
    }





    Pair<Double, Double> curStocks = this.BuyDates.get(curBuyKey);

    // This is the map with the total value at each date that we will return.
    Map<LocalDate, Double> allVals = new HashMap<LocalDate, Double>();

    for(LocalDate key: priceKeys) {

      // If our current date is after/equal to the current buy key
      // First check that we are before the next buy Key
         // If not then ignore --> we only want values after/on the first valid buy date
         // If true then check that we are before the next buyDate
            // If false then we update the buyDate, otherwise continue
      if(!key.isBefore(curBuyKey)) {
        // If we have a next key check that we are not on or after it
        // If we are not before then update the shares and comission fee
        if(!Objects.isNull(nextBuy) && !key.isBefore(nextBuy)) {
          curBuyKey = nextBuy;

          if(buyIt.hasNext()) {
            nextBuy = buyIt.next();
          } else {
            nextBuy = null;
          }

          curBuy = BuyDates.get(curBuyKey);
          curTotStock += curBuy.a;
          curTotComiss += curBuy.b;
        }

        // once everything is updated we can continue
        double curPrice = newPrices.get(key);
        double curValue = (curPrice * curTotStock) - curTotComiss;
        allVals.put(key, curValue);

      }

      // else if(current key is before the current buy key return nothing)

    }

    return allVals;

  }


  /**
   * If the date string passed to this == "current" then it will.
   * fetch the most current date available in stockData, otherwise it.
   * searches stockData for key matching the date inputted.
   * If this date is not found it will print "NO DATA" in each of.
   * the columns except the ticker column.
   */
  @Override
  public String printDataAt(String date) {

    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    Set<LocalDate> keys = stockData.keySet();

    LocalDate myKey = null;
    String output = "";

    if (date.contains("current")) {
      myKey = Collections.max(keys);
      date = dtf.format(myKey);
    } else {
      // create a date object from our string date
      myKey = LocalDate.parse(date);
    }


    if (!stockData.containsKey(myKey)) {
      output = "| " + padOne(ticker, 6) + " | " + date + " | "
              + padOne(String.valueOf(shares), 13)
              + " |       NO DATA      |       NO DATA     |";
    } else {
      // this makes sure we dont have big numbers in scientific notation
      // It will print up to 10 digits
      DecimalFormat df = new DecimalFormat("#");
      df.setMaximumFractionDigits(10);


      //TODO: fix here
      double myData = stockData.get(myKey);

      String[] padded = getPadding(ticker, shares, df, myData);


      output = "| " + padded[0]
              + " | " + date
              + " | " + padded[1]
              + " | " + padded[2]
              + " | " + padded[3] + " |";

    }


    return output;
  }


  /**
   * This function returns the actual double value of any main
   * numeric stock data point. It takes a date which is in the
   * same format as above (if date == "current" then get the
   * latest value otherwise fetch the value at date). Unlike
   * above this one does not take an index and just returns
   * the whole array of inputs for efficiency.
   */
  @Override
  public double getData(String date) {

    Set<LocalDate> keys = stockData.keySet();

    LocalDate myKey = null;
    double output = 0.0;

    if (date.contains("current")) {
      myKey = Collections.max(keys);
    } else {
      // create a date object from our string date
      myKey = LocalDate.parse(date);
    }

    //TODO: Double check this function
    if (stockData.containsKey(myKey)) {
      output = stockData.get(myKey);
    }

    return output;
  }

  /**
   * basic getter for # of shares.
   *
   * @return the number of shares.
   */
  @Override
  public double getShares() {
    return this.shares;
  }

  /**
   * basic getter for the ticker.
   */
  @Override
  public String getTicker() {
    return this.ticker;
  }

  /**
   * toString() no prints most the current data.
   */

  @Override
  public String toString() {
    return this.printDataAt("current");
  }

  // used to change the number of shares if a certain ticker is
  // added to a portfolio multiple times
  public SmartStock addShares(String BuyData) throws IllegalArgumentException {

    Map<LocalDate, Pair<Double,Double>> myBuyDates = new HashMap<>();
    myBuyDates.putAll(this.BuyDates);

    try {
      myBuyDates.putAll(parseBuyDates(BuyData));
    } catch (Exception e) {
      throw e;
    }

    double totShares = this.shares;
    for(LocalDate key: myBuyDates.keySet()) {
      totShares += myBuyDates.get(key).a;
    }


    return new SmartStock(this.ticker, totShares, this.stockData, myBuyDates);
  }

  public Stock addShares(double numShares) throws IllegalArgumentException {
    double totShares = this.shares + numShares;
    LocalDate myDate = LocalDate.now();

    HashMap<LocalDate, Pair<Double,Double>> myBuyDates = new HashMap<LocalDate, Pair<Double,Double>>();
    myBuyDates.putAll(this.BuyDates);

    Pair<Double,Double> myPair = new Pair<Double,Double>(numShares,0.0);
    myBuyDates.put(myDate,myPair);


    return new SmartStock(this.ticker, totShares, this.stockData, myBuyDates);
  }


  private String padOne(String shares, int size) {

    int padAmount = Math.max(0, size - shares.length());
    int leftPad = 0;
    int rightPad = 0;
    if (padAmount != 0) {
      leftPad = padAmount / 2;
      rightPad = padAmount - leftPad;
    }


    String output = padRight(padLeft(shares, leftPad), rightPad);

    return output;
  }

  private String[] getPadding(String ticker, double shares, DecimalFormat myDF, double myData) {
    int[] padAmount = new int[4];

    double totVal = myData * ((double) shares);

    padAmount[0] = Math.max(0, 6 - ticker.length());
    padAmount[1] = Math.max(0, 13 - String.valueOf(shares).length());
    padAmount[2] = Math.max(0, 18 - myDF.format(myData).length());
    padAmount[3] = Math.max(0, 17 - myDF.format(totVal).length());


    int[] leftPad = new int[4];
    int[] rightPad = new int[4];

    for (int i = 0; i < 4; i++) {
      if (padAmount[i] != 0) {
        leftPad[i] = padAmount[i] / 2;
        rightPad[i] = padAmount[i] - leftPad[i];
      } else {
        leftPad[i] = 0;
        rightPad[i] = 0;
      }

    }

    String[] output = new String[7];

    output[0] = padRight(padLeft(ticker, leftPad[0]), rightPad[0]);
    output[1] = padRight(padLeft(String.valueOf(shares), leftPad[1]), rightPad[1]);
    output[2] = padRight(padLeft(myDF.format(myData), leftPad[2]), rightPad[2]);
    output[3] = padRight(padLeft(myDF.format(totVal), leftPad[3]), rightPad[3]);

    return output;
  }

  // Example String:
  // "(2020-10-05,32.4),(2022-09-31,46.7),...
  // IF A DATE IS ENTERED MORE THAN ONCE THEN ONLY THE
  // FIRST TIME IT WAS ENTERED WILL BE USED
  private Map<LocalDate, Double> parseStock(String data) throws IllegalArgumentException {

    if (!data.matches("[0-9-,.); (]+")) {
      throw new IllegalArgumentException("Unexpected character was found in stock data. "
              + "Please try again.");
    }

    Map<LocalDate, Double> stockDateData = new HashMap<LocalDate, Double>();
    String[] dateInfo = data.split(";");

    for (int i = 0; i < dateInfo.length; i++) {

      String m2 = dateInfo[i].replaceAll("[() ]", "");

      String[] info2 = m2.split(",");

      // This will throw an error if the date was entered wrong so ok here
      LocalDate myKey = LocalDate.parse(info2[0]);

      if(info2[1].length() == 0) {
        if(info2[2].length() != 0) {
          info2[1] = info2[2];
        } else {
          throw new IllegalArgumentException("Unexpected input in string data.");
        }
      }
      if (!stockDateData.containsKey(myKey)) {
        stockDateData.put(myKey, Double.parseDouble(info2[1]));
      }
      // This will throw an error if the # was entered wrong, so we should be good here.

    }

    return stockDateData;
  }


  /**
   * Prints only the top 50 dates.
   */

  public String sharesToJSON() {

    StringBuilder outBuild = new StringBuilder();
    List<LocalDate> topDates = new ArrayList<LocalDate>(stockData.keySet());
    Collections.sort(topDates, Collections.reverseOrder());
    topDates = topDates.subList(0, min(50, topDates.size()));
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("Stock1-MM-dd");
    for (int i = 0; i < topDates.size(); i++) {
      LocalDate key = topDates.get(i);
      String curPrice = String.valueOf(stockData.get(key));
      outBuild.append("          \"");
      outBuild.append(dtf.format(key)).append("\": \"");
      outBuild.append(curPrice).append("\"");

      if (i == topDates.size() - 1) {
        outBuild.append("\n");
      } else {
        outBuild.append(",\n");
      }

    }
    //l = l.subList(0,10);
    return outBuild.toString();
  }


  /**
   * Method to get the stock data from the stocks price list.
   *
   * This method also allows you to input date strings to get daily data between the two dates.
   * If the date starts in the middle of a time frame type it will return the price at the end
   * of the timeframe.
   * @param date1 This is the date to start our time frame
   * @param date2 This is a second optional date to end gathering stock data after.
   * @param buyDate The first date this stock was bought
   * @throws IllegalArgumentException
   * @return the map of date and ticker.
   */


  private Map<LocalDate, Double> getMyStockDate(String date1,
                                                String date2,
                                                String buyDate) throws IllegalArgumentException {
    //System.out.println("WHAT?");

    // This part is setup for our later parsing

    LocalDate startDate;
    LocalDate endDate;
    try{
      startDate = LocalDate.parse(date1);
      endDate = LocalDate.parse(date2);
    } catch(Exception e) {
      throw new IllegalArgumentException("Your date strings could not be parsed! " +
              "Please check that your date input strings are in YYYY-MM-DD format.");
    }


    if( startDate.isAfter(endDate) ) {
      throw new IllegalArgumentException("The end date must be after the start date." +
              " Please recheck your date inputs and try again.");
    }
    LocalDate[] startEndDate = new LocalDate[2];
    LocalDate buyD;

    try{
      buyD = LocalDate.parse(buyDate);
    } catch(Exception e) {
      throw new IllegalArgumentException("Your buy-date could not be parsed!" +
              " Please check the input.");
    }


    if(buyD.isAfter(endDate)) {
      return new HashMap<LocalDate, Double>();
    }

    final LocalDate finStart;
    if (buyD.isAfter(startDate)) {
      finStart = buyD;
    } else {
      finStart = startDate;
    }

    HashMap<LocalDate, Double> newData = new HashMap<LocalDate, Double>(this.stockData);

    newData.keySet().removeIf(k -> k.isBefore(finStart) || k.isAfter(endDate));


    return newData;
  }

}




//toString();
//| TICKER | DATE | Num_Shares | open | high|  low| close| volume|
//| TICKER | DATE | Num_Shares | open | high|  low| close| volume|
//| TICKER | DATE | Num_Shares | open | high|  low| close| volume|
