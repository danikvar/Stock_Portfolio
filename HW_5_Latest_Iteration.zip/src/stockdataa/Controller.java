package stockdataa;

import java.io.FileNotFoundException;

/**
 * Controller interface that performs all operations of the TextController class.
 */

public interface Controller {
  void controller() throws FileNotFoundException;
}
