
import java.io.IOException;
import stockData.Controller;
import stockData.Portfolio;
import stockData.TextController;
import stockData.TextGUI;


public class PortfolioApplication {
  public static void main(String[] args) throws IOException {

    Portfolio model = new Portfolio();
    TextGUI view = new TextGUI(System.out);
    Controller control = new TextController(model, System.in, view);
    control.controller();

  }
}

