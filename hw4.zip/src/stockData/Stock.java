package stockData;

public interface Stock {
}
