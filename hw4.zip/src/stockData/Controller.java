package stockData;

import java.io.FileNotFoundException;

public interface Controller {
  void controller() throws FileNotFoundException;
}
