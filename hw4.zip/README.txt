 FEATURES :

	•	Our program allows a single or multiple users to create any number of portfolios with numerous stocks.
	•	At any point, the user can view their portfolio to examine the contents of it.
	•	Every time some stock is added, or some modification is made by the user, it will be saved by our program.
	•	The user can add any number of stocks.
	•	Every file is saved and can be loaded to retrieve data from them.
	•	A user can determine the total value of his/her portfolio at any valid date.
	•	The user can also simply provide a file path where the file they want to upload as the portfolio is present. Our program will save that file as a portfolio.
	•	The user is given an option to manually enter stock data, upload them via files or ask the program to use the API.
